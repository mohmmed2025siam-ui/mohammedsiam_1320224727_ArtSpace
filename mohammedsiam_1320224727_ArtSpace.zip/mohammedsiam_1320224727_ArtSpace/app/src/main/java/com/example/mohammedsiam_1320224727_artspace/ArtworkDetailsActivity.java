package com.example.mohammedsiam_1320224727_artspace;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class ArtworkDetailsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_artwork_details);

        TextView tvDetails = findViewById(R.id.tvDetails);
        Button btnVisit = findViewById(R.id.btnVisit);
        Button btnBack = findViewById(R.id.btnBack);

        Intent receivedIntent = getIntent();
        String title = receivedIntent.getStringExtra("title");
        String artist = receivedIntent.getStringExtra("artist");
        String year = receivedIntent.getStringExtra("year");
        String url = receivedIntent.getStringExtra("url");

        tvDetails.setText("Title: " + title + "\n\n"
                + "Artist: " + artist + "\n\n"
                + "Year: " + year);

        btnVisit.setOnClickListener(v -> {
            Intent webIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
            startActivity(webIntent);
        });

        btnBack.setOnClickListener(v -> finish());
    }
}