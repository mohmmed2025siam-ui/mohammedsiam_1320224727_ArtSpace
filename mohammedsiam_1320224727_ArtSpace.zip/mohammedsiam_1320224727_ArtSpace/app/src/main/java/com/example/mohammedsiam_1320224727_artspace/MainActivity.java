package com.example.mohammedsiam_1320224727_artspace;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    // ====== بيانات اللوحات الست (6 مصفوفات) ======
    int[] images = {
            R.drawable.art1, R.drawable.art2, R.drawable.art3,
            R.drawable.art4, R.drawable.art5, R.drawable.art6
    };

    String[] titles = {
            "Mona Lisa", "Starry Night", "The Scream",
            "Girl with a Pearl Earring", "The Persistence of Memory", "Guernica"
    };

    String[] artists = {
            "Leonardo da Vinci", "Vincent van Gogh", "Edvard Munch",
            "Johannes Vermeer", "Salvador Dali", "Pablo Picasso"
    };

    String[] years = {
            "1503", "1889", "1893", "1665", "1931", "1937"
    };

    String[] urls = {
            "https://en.wikipedia.org/wiki/Mona_Lisa",
            "https://en.wikipedia.org/wiki/The_Starry_Night",
            "https://en.wikipedia.org/wiki/The_Scream",
            "https://en.wikipedia.org/wiki/Girl_with_a_Pearl_Earring",
            "https://en.wikipedia.org/wiki/The_Persistence_of_Memory",
            "https://en.wikipedia.org/wiki/Guernica_(Picasso)"
    };

    // رقم اللوحة الحالية (يبدأ من 0)
    int currentIndex = 0;

    TextView tvCounter, tvTitle, tvArtist;
    ImageView imgArtwork;
    Button btnPrevious, btnNext;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // ربط العناصر بالـ XML
        tvCounter = findViewById(R.id.tvCounter);
        tvTitle = findViewById(R.id.tvTitle);
        tvArtist = findViewById(R.id.tvArtist);
        imgArtwork = findViewById(R.id.imgArtwork);
        btnPrevious = findViewById(R.id.btnPrevious);
        btnNext = findViewById(R.id.btnNext);

        // استرجاع الرقم المحفوظ بعد التدوير
        if (savedInstanceState != null) {
            currentIndex = savedInstanceState.getInt("current_index", 0);
        }

        // عرض اللوحة الحالية
        showArtwork();

        // زر التالي
        btnNext.setOnClickListener(v -> {
            currentIndex++;
            showArtwork();
        });

        // زر السابق
        btnPrevious.setOnClickListener(v -> {
            currentIndex--;
            showArtwork();
        });

        // النقر على الصورة => فتح الشاشة الثانية (Explicit Intent)
        imgArtwork.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, ArtworkDetailsActivity.class);
            intent.putExtra("title", titles[currentIndex]);
            intent.putExtra("artist", artists[currentIndex]);
            intent.putExtra("year", years[currentIndex]);
            intent.putExtra("url", urls[currentIndex]);
            startActivity(intent);
        });
    }

    // دالة تحدّث كل المعلومات على الشاشة
    private void showArtwork() {
        imgArtwork.setImageResource(images[currentIndex]);
        tvTitle.setText(titles[currentIndex]);
        tvArtist.setText(artists[currentIndex] + ", " + years[currentIndex]);
        tvCounter.setText((currentIndex + 1) + " / " + images.length);

        // تعطيل السابق في أول لوحة، والتالي في آخر لوحة
        btnPrevious.setEnabled(currentIndex > 0);
        btnNext.setEnabled(currentIndex < images.length - 1);
    }

    // حفظ الحالة قبل تدوير الشاشة
    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putInt("current_index", currentIndex);
    }
}